?package(veejay):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="veejay" command="/usr/bin/veejay"
