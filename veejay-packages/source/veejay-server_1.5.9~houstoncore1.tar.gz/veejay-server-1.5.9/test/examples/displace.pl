my $i;

for(my $j = 0; $j < 40; $j++)
{ 

for($i = 0; $i < 100; $i ++ )
{
	print("361:0 9 233 $i $i;\n");
	print("+25\n"); 
}
for($i = 100; $i > 1 ; $i -- )
{
	print("361:0 9 233 $i $i;\n");
	print("+25\n");

}
}
